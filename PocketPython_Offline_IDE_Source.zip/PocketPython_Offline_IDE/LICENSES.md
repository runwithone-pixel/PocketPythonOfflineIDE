# Dependency and license inventory

This is an inventory of dependencies configured in source, not a full generated SBOM. The final built APK must be audited after a successful Gradle dependency resolution.

| Component | Configured version | License / source | Notes |
|---|---|---|---|
| Chaquopy Android Python runtime/plugin | 17.2.0 | MIT; https://chaquo.com/chaquopy/chaquopy-is-now-open-source/ | Embeds CPython into Android |
| CPython | 3.13 line | Python Software Foundation License; https://docs.python.org/3/license.html | Interpreter and standard library supplied through Chaquopy |
| pip | 26.2.2 | MIT; https://github.com/pypa/pip/blob/main/LICENSE.txt | Bundled for optional compatible-wheel installation |
| Android Gradle Plugin | 8.9.2 | Apache-2.0; https://developer.android.com/studio/build | Build-time only |
| Kotlin / Compose compiler plugin | 2.1.20 | Apache-2.0; https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt | Build/runtime framework |
| Jetpack Compose BOM | 2025.08.00 | Apache-2.0; https://github.com/androidx/androidx | BOM selects Compose library versions |
| AndroidX Activity Compose | 1.10.1 | Apache-2.0; https://github.com/androidx/androidx | Activity integration |
| AndroidX Lifecycle | 2.9.2 | Apache-2.0; https://github.com/androidx/androidx | Lifecycle dependencies |
| Kotlin Coroutines Android | 1.10.2 | Apache-2.0; https://github.com/Kotlin/kotlinx.coroutines | Background execution and UI dispatch |
| JUnit | 4.13.2 | EPL-1.0; https://github.com/junit-team/junit4 | Test scope only |

No NumPy, Pillow, SymPy, Requests, or Matplotlib package is bundled by default. Optional user-installed wheels retain their own licenses and should be audited separately by each user or distributor before redistribution.
