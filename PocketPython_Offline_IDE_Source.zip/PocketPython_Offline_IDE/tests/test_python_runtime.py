import importlib.util
import os
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYDIR = ROOT / "app" / "src" / "main" / "python"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


runner = load_module("pocketpython_runner_test", PYDIR / "runner.py")
pip_manager = load_module("pocketpython_pip_manager_test", PYDIR / "pip_manager.py")


class FakeBridge:
    output = []
    input_value = "Ada"
    cancel_after = None
    check_count = 0
    cancelled = False

    @classmethod
    def reset(cls):
        cls.output = []
        cls.check_count = 0
        cls.cancelled = False
        cls.cancel_after = None

    @classmethod
    def write(cls, text):
        cls.output.append(str(text))

    @classmethod
    def readLine(cls):
        return cls.input_value

    @classmethod
    def isCancelled(cls):
        cls.check_count += 1
        if cls.cancel_after is not None and cls.check_count >= cls.cancel_after:
            cls.cancelled = True
        return cls.cancelled


runner.PythonBridge = FakeBridge
pip_manager.PythonBridge = FakeBridge


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        FakeBridge.reset()
        self.temp = tempfile.TemporaryDirectory()
        self.work = Path(self.temp.name) / "project"
        self.packages = Path(self.temp.name) / "site-packages"
        self.work.mkdir()
        self.packages.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def run_code(self, source, filename="main.py"):
        return runner.run_code(source, str(self.work), str(self.packages), str(self.work / filename))

    def test_print_and_logic(self):
        status = self.run_code("print(2 + 3)\nprint(True and not False)")
        self.assertEqual(status, "completed")
        self.assertIn("5\nTrue\n", "".join(FakeBridge.output))

    def test_input_and_loop(self):
        FakeBridge.input_value = "Ada"
        status = self.run_code('name = input("Name? ")\nfor i in range(1, 4):\n    print(i, name)')
        output = "".join(FakeBridge.output)
        self.assertEqual(status, "completed")
        self.assertIn("Name? ", output)
        self.assertIn("3 Ada", output)

    def test_traceback_has_filename_and_line(self):
        status = self.run_code('print("before")\nraise ValueError("broken")', "lesson.py")
        output = "".join(FakeBridge.output)
        self.assertEqual(status, "error")
        self.assertIn("ValueError: broken", output)
        self.assertIn("lesson.py", output)
        self.assertIn("line 2", output)

    def test_infinite_loop_can_be_cancelled_by_trace_hook(self):
        FakeBridge.cancel_after = 100
        status = self.run_code("while True:\n    x = 1")
        self.assertEqual(status, "stopped")
        self.assertIn("Execution stopped by user", "".join(FakeBridge.output))

    def test_installed_package_path_can_be_refreshed(self):
        import json
        old_path = list(__import__("sys").path)
        try:
            result = json.loads(runner.refresh_package_imports(str(self.packages)))
            self.assertTrue(result["success"])
            self.assertEqual(__import__("sys").path[0], str(self.packages.resolve()))
        finally:
            __import__("sys").path[:] = old_path

    def test_syntax_error_returns_error(self):
        status = self.run_code("if True print('missing colon')")
        self.assertEqual(status, "error")
        self.assertIn("SyntaxError", "".join(FakeBridge.output))


class WheelManagerTests(unittest.TestCase):
    def make_wheel(self, directory: Path, name="tiny_demo", version="1.0.0", requires=None):
        directory.mkdir(parents=True, exist_ok=True)
        wheel_path = directory / f"{name}-{version}-py3-none-any.whl"
        dist = f"{name}-{version}.dist-info"
        metadata = f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n"
        if requires:
            for requirement in requires:
                metadata += f"Requires-Dist: {requirement}\n"
        wheel_file = "Wheel-Version: 1.0\nGenerator: pocketpython-test\nRoot-Is-Purelib: true\nTag: py3-none-any\n"
        package_import = name.replace("-", "_")
        with zipfile.ZipFile(wheel_path, "w") as archive:
            archive.writestr(f"{package_import}/__init__.py", "VALUE = 'works offline'\n")
            archive.writestr(f"{dist}/METADATA", metadata)
            archive.writestr(f"{dist}/WHEEL", wheel_file)
            archive.writestr(f"{dist}/top_level.txt", package_import + "\n")
            archive.writestr(f"{dist}/RECORD", "")
        return wheel_path

    def test_inspect_wheel_reads_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            wheel = self.make_wheel(Path(temp))
            result = pip_manager.inspect_wheel(str(wheel))
            import json
            data = json.loads(result)
            self.assertTrue(data["valid"])
            self.assertEqual(data["name"], "tiny_demo")
            self.assertEqual(data["version"], "1.0.0")

    def test_offline_install_of_cached_universal_wheel(self):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            wheelhouse = root / "wheelhouse"
            wheel = self.make_wheel(wheelhouse)
            site = root / "site-packages"
            cache = root / "cache"
            result = json.loads(pip_manager.import_and_install_wheel(str(wheel), str(site), str(wheelhouse), str(cache)))
            self.assertTrue(result.get("success"), result)
            self.assertTrue((site / "tiny_demo" / "__init__.py").exists())
            installed = json.loads(pip_manager.list_installed(str(site)))
            self.assertTrue(any(p["name"] == "tiny_demo" for p in installed["packages"]))
            import sys
            old_path = list(sys.path)
            try:
                runner.refresh_package_imports(str(site))
                imported = __import__("tiny_demo")
                self.assertEqual(imported.VALUE, "works offline")
            finally:
                sys.path[:] = old_path
                sys.modules.pop("tiny_demo", None)

    def test_missing_dependency_fails_without_claiming_success(self):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            wheelhouse = root / "wheelhouse"
            self.make_wheel(wheelhouse, name="needs_missing", requires=["dependency_that_is_not_cached_xyz>=1"])
            site = root / "site-packages"
            cache = root / "cache"
            result = json.loads(pip_manager.install_offline("needs_missing==1.0.0", str(site), str(wheelhouse), str(cache)))
            self.assertFalse(result.get("success"), result)
            self.assertIn("missing", result.get("message", "").lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
