# Test and acceptance report

## Result summary

- Host-side Python tests: **9 passed, 0 failed** on the local CPython 3.13 environment.
- Python source bytecode compilation: run during validation.
- XML files: checked for well-formedness during project preparation.
- Android Gradle compile/APK build: **not run**; Android SDK and Gradle were not available in the preparation environment, and external dependency downloads were unavailable.
- Android installation and device tests: **not run**.

The host tests are useful but are not proof that the embedded Chaquopy runtime or UI works on Android.

## Host tests that passed

| Test | Result | What it verifies |
|---|---|---|
| `test_print_and_logic` | PASS | Host Python execution adapter captures output and evaluates expressions |
| `test_input_and_loop` | PASS | Host bridge exercises `input()` and loop output |
| `test_installed_package_path_can_be_refreshed` | PASS | Runtime helper adds the private package directory to Python import search paths |
| `test_traceback_has_filename_and_line` | PASS | A runtime error includes filename and line number |
| `test_infinite_loop_can_be_cancelled_by_trace_hook` | PASS | Trace hook interrupts a pure-Python loop in the host test |
| `test_syntax_error_returns_error` | PASS | Syntax failure is reported as an error |
| `test_inspect_wheel_reads_metadata` | PASS | Wheel archive metadata is read |
| `test_offline_install_of_cached_universal_wheel` | PASS | Host pip can install a synthetic universal wheel from local files |
| `test_missing_dependency_fails_without_claiming_success` | PASS | Offline install fails instead of reporting success when a dependency is unavailable |

The wheel installation tests run on the host interpreter with a synthetic `py3-none-any` wheel. They do **not** test Android-tagged native wheels or pip behavior inside Chaquopy.

## Acceptance matrix

| Requirement | Current evidence/status |
|---|---|
| Native Kotlin/Compose Android source | Implemented in source; not Gradle-compiled here |
| Embedded CPython 3.13 | Configured through Chaquopy; APK not built here |
| `print`, conditionals, loops, exceptions | Host runner tests pass; Android runtime unverified |
| Interactive `input()` | Java queue + output bridge implemented; Android UI behavior unverified |
| Run off main thread and Stop control | Coroutine + trace cancellation implemented; Android stress test unverified; native C calls cannot be reliably force-killed by a Python trace hook |
| Autosave/recovery checkpoint | Atomic file/checkpoint implementation present; force-stop/clear-recents acceptance test not performed |
| Project create/rename/duplicate/delete | Source implementation present; no Android UI test |
| `.py` import/export and ZIP project export/import | Source implementation present; no Android UI test |
| Standard-library inventory | Selected modules queried dynamically in interpreter; not run in Chaquopy build here |
| Online/offline package install and local wheel | Host tests pass for limited cases; Chaquopy runtime is unverified and not ready to claim production reliability |
| Compatible library imports after airplane-mode restart | Not tested on Android |
| 4 GB RAM performance | Not tested on device |
| APK size/installability | Unknown until CI build completes |
| No ads / account / subscription | No code for ads, account, or subscription; not monetized |
| No cloud code execution | Python runner executes in process on-device; package metadata/wheels use internet only when user requests package operations |

## Required device checks before a production release

1. Build and install the APK on an Android 12 ARM64 device.
2. Run `print(1 + 1)`, `input()`, `if/else`, loops, syntax errors, and exceptions.
3. Test Stop on a tight Python loop and document limitations for native/blocking code.
4. Edit without manually saving, minimize, remove from Recents, relaunch, and compare the exact source text.
5. Install a confirmed Android-compatible wheel while online; restart, turn on airplane mode, import and use the package.
6. Attempt installation with an absent dependency and an incompatible wheel; verify no false success and no corruption of previously installed packages.
7. Import/export `.py` and ZIP projects, and test low free storage and repeated app relaunch.
8. Record APK size, startup time, RAM use, logs, Android version, CPU ABI and test results.
