# Building PocketPython Offline IDE

## Toolchain

- JDK 17
- Python 3.13 (build-time Python version must match the embedded major/minor version)
- Gradle 8.11.1
- Android SDK platform 35 and build-tools 35.0.0
- Internet access for the first Gradle/dependency/runtime download

Chaquopy 17.2 supports AGP 7.3–9.4 and requires `minSdk >= 24`. This project selects AGP 8.9.2, Gradle 8.11.1, Python 3.13, API 35, and ARM64 plus x86_64. See the [official Chaquopy Android setup documentation](https://chaquo.com/chaquopy/doc/current/android.html).

## Automated build

The workflow `.github/workflows/build-apk.yml` runs the Python host tests, installs the Android SDK platform/build tools, executes `assembleDebug`, and stores the APK as a 14-day Actions artifact. The resulting artifact is a **debug-signed test APK**, not a Play Store release. A production release needs a secure signing configuration and release validation.

## Local build

```bash
python -m unittest discover -s tests -v
python -m py_compile app/src/main/python/runner.py app/src/main/python/pip_manager.py
gradle --version
gradle --no-daemon --stacktrace assembleDebug
```

The expected output is `app/build/outputs/apk/debug/app-debug.apk`. Do not create a download link for that path unless the build actually succeeds.

## Troubleshooting

- **No Python 3.13 found:** Install Python 3.13 or configure Chaquopy `buildPython` to point to it.
- **No matching distribution:** The dependency may not publish a compatible Android wheel for CPython 3.13/your ABI. See `PACKAGE_COMPATIBILITY.md`.
- **Build downloads fail:** Retry on a stable network. The Gradle plugin and embedded Python artifacts are not bundled in this source ZIP.
- **APK installs but Python cannot start:** Capture the Android Logcat stack trace. A successful host-side unit test does not verify the Chaquopy application runtime.
- **Library installation fails in the app:** Save the full package manager error, confirm a wheel exists for Android/CPython 3.13, and check that each dependency has a compatible wheel. The in-app runtime installer still requires real-device validation.
