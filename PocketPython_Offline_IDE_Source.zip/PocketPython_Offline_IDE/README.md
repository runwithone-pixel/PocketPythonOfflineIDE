# PocketPython Offline IDE

PocketPython is an **early native Android source project** for a small offline-first Python IDE. It uses Kotlin, Jetpack Compose, a native `EditText`-based editor, and embedded CPython through Chaquopy. This is not a website or a remote/cloud code runner.

> **Build and verification status:** The host-side Python tests pass (8/8). In the environment where this project was prepared, Android SDK/Gradle were unavailable and external dependency downloads could not be completed, so an APK has **not** been built here. The included GitHub Actions workflow is designed to build an installable debug APK. No Android device acceptance test has yet been performed. Read [TEST_REPORT.md](TEST_REPORT.md) before relying on it.

## Intended capabilities

- Embedded CPython 3.13; Python execution is local, with output and interactive `input()` bridged to the app console.
- App-private `.py` files, atomic saves, recovery checkpoints, a debounced autosave, and a save when the activity pauses.
- Create, rename, duplicate and delete source files; import/export `.py`; export/import project ZIP files.
- Lightweight editor with line-number gutter, basic token colouring, auto-indentation, paired delimiters, undo/redo, find/replace, font size, and word-wrap setting.
- Runtime discovery of selected standard-library modules.
- Optional package manager using binary wheels only, an app-private wheelhouse, and staged install replacement. It deliberately does not build native extensions from source.
- Dark/light theme and app-private settings.

Features are implemented in this source tree but not all have been verified on a real Android runtime. In particular, runtime `pip` operation and Android-specific wheel behavior must be tested on device before treating package installation as production-ready.

## Build an installable debug APK

### Recommended: GitHub Actions

1. Put the contents of this folder into a GitHub repository.
2. Push the default branch as `main` or `master`, or open **Actions → Build PocketPython Offline IDE APK → Run workflow**.
3. Wait for the job to finish successfully.
4. Open the completed workflow run and download the artifact named `PocketPython-Offline-IDE-debug-apk`.
5. Extract the APK and install it on a compatible Android device. Android may ask you to allow installs from the app you used to open the APK.

The workflow downloads open-source build dependencies, Android platform 35, and Chaquopy's embedded Python artifacts. Initial **building** therefore needs internet access. The installed app is intended to run ordinary local Python programs without internet.

### Local build

Requirements: JDK 17, Python 3.13 on `PATH`, Gradle 8.11.1, Android SDK platform 35 and build tools 35.0.0. From this folder run:

```bash
python -m unittest discover -s tests -v
python -m py_compile app/src/main/python/runner.py app/src/main/python/pip_manager.py
gradle --no-daemon assembleDebug
```

The APK should be at `app/build/outputs/apk/debug/app-debug.apk`. This path exists only after a successful build.

## First-run checks

1. Install/open the app and wait for `StarterProject/main.py` to load.
2. Tap **Run**. The starter code asks for a name in the Output panel; enter a value and tap **Send**.
3. Try `print(2 + 3)`, an `if` statement, and a loop.
4. Edit code and wait for the Saved indicator. Force-stop/reopen only as a test after you have exported a backup.
5. Test package installation using a small pure-Python package with a compatible wheel, then enable airplane mode and import it.
6. Test missing dependencies and incompatible wheels; the manager should report failure rather than success.

These are manual test suggestions, not tests already completed on Android.

## Offline and network behavior

| Activity | Needs internet? |
|---|---|
| Edit, autosave, reopen `.py` files | No |
| Run code using the bundled interpreter and standard library | No |
| Use a package already installed in app-private storage | No |
| Search an exact package name on PyPI | Yes |
| Install package wheels not already cached | Yes |
| Install from a local `.whl` and fully cached dependencies | No |
| Export/import through Android's system file picker | No, unless the selected provider itself is online-only |

The app contains the Android `INTERNET` permission because package search and optional online installation use it. Python source and project contents are not sent to a server by the runner. Python code and third-party packages execute with the permissions available to this app; only install packages you trust.

## Storage and recovery

Projects and installed wheels live in app-private internal storage. The editor uses atomic writes plus separate recovery checkpoints. This should help recover from process death, but the Android process-kill/restore acceptance test has **not yet been run on a device**, so do not treat recovery as proven. Export `.py` files or a ZIP backup before uninstalling or clearing app data. Like ordinary Android apps, this app cannot preserve private files after its app data is explicitly cleared or the app is uninstalled.

## Target compatibility

- Minimum Android API: 24 (Android 7.0).
- Embedded Python: CPython 3.13 through Chaquopy 17.2.0.
- Bundled ABIs: `arm64-v8a` and `x86_64`; 32-bit ARM is not included.
- A typical modern ARM64 Android phone is the intended target. Device-specific installation, RAM, performance, `input()`, cancellation and persistence remain to be verified.

## Documentation

- [Building and troubleshooting](BUILDING.md)
- [Package compatibility and offline wheels](PACKAGE_COMPATIBILITY.md)
- [Test and acceptance report](TEST_REPORT.md)
- [Dependency and license inventory](LICENSES.md)
