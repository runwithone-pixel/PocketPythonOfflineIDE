# Package compatibility and offline installation

## Embedded interpreter

The app embeds CPython 3.13 with Chaquopy 17.2.0 and targets `arm64-v8a` and `x86_64`. The runtime uses the CPython standard library supplied by Chaquopy. The UI checks selected module names with `importlib.util.find_spec` in the embedded interpreter instead of assuming every module is present.

Chaquopy's official documentation lists Android-specific unsupported modules, including `crypt`, `grp`, `nis`, `spwd`, `curses`, `dbm.gnu`, `dbm.ndbm`, `readline`, `tkinter`, `turtle`, and `ensurepip`: https://chaquo.com/chaquopy/doc/current/android.html#python-standard-library. Availability of other modules should still be checked at runtime.

## Third-party package policy

No third-party scientific/data packages are preinstalled by default. The build bundles pip 26.2.2; users can optionally install packages. The in-app manager deliberately uses `--only-binary=:all:` and does not compile source distributions.

A package can install only if all required dependencies can be resolved to wheels compatible with the embedded CPython version, Android ABI/API level, and native-library requirements. An ordinary Linux `manylinux` wheel is not an Android wheel. A `py3-none-any` wheel is architecture-independent but may still depend on unavailable packages or operating-system features.

The online manager uses PyPI and the Chaquopy wheel index. The existence of a name on PyPI does **not** mean it is installable. `numpy`, `Pillow`, `sympy`, `requests`, and `matplotlib` are not pre-bundled and are not claimed as tested by this project. Availability depends on the exact version and wheel set; native-extension packages need Android-compatible builds.

## Offline install

1. Install while online, or import a compatible `.whl` file through the Library Manager.
2. The manager keeps the wheel and dependencies in its private wheelhouse.
3. Choose **Install offline** only when every dependency wheel needed for the requested package is already cached. Otherwise the operation should fail with details.
4. After a successful installation, test the import and run a small program with airplane mode enabled.

Local wheel import validates the archive and metadata first, then pip checks the compatibility tags and dependencies during installation. Merely importing/caching a `.whl` is not the same as successfully installing it.

## Runtime installer status

The installer is implemented around the bundled pip CLI, binary-wheel-only resolution, local wheelhouse, and a staged package-directory replacement. Its host-side tests passed for a synthetic universal wheel and for a missing dependency. It has **not been run inside Chaquopy on Android** in this delivery. Therefore, runtime online/offline package installation must be regarded as an implementation awaiting device verification, not a confirmed production capability.
