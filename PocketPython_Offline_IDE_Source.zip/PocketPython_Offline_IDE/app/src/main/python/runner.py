"""Execution adapter for the bundled CPython interpreter.

This module is deliberately local. It never sends user source code to a server.
"""
import builtins
import importlib.util
import io
import json
import os
import sys
import traceback

try:
    from com.pocketpython.offline import PythonBridge
except Exception:  # Development/test fallback only; Android uses the Java bridge.
    class PythonBridge:  # pragma: no cover - only a local fallback
        @staticmethod
        def write(text):
            sys.__stdout__.write(text)
            sys.__stdout__.flush()

        @staticmethod
        def readLine():
            return input()

        @staticmethod
        def isCancelled():
            return False


class _StopExecution(BaseException):
    pass


class _ConsoleStream:
    encoding = "utf-8"
    errors = "replace"

    def write(self, value):
        text = str(value)
        PythonBridge.write(text)
        return len(text)

    def flush(self):
        return None

    def isatty(self):
        return True

    def writable(self):
        return True


class _InputCancelled(BaseException):
    pass


def run_code(source, working_directory, package_directory, filename=None):
    """Execute one editor snapshot and return completed, error, or stopped."""
    source = str(source)
    working_directory = os.path.abspath(str(working_directory))
    package_directory = os.path.abspath(str(package_directory))
    os.makedirs(working_directory, exist_ok=True)
    os.makedirs(package_directory, exist_ok=True)

    old_stdout, old_stderr, old_cwd, old_trace = sys.stdout, sys.stderr, os.getcwd(), sys.gettrace()
    old_path = list(sys.path)
    editor_filename = os.path.abspath(str(filename)) if filename else os.path.join(working_directory, "main.py")
    package_path_added = package_directory not in sys.path
    if package_path_added:
        sys.path.insert(0, package_directory)

    console = _ConsoleStream()
    sys.stdout = console
    sys.stderr = console
    os.chdir(working_directory)

    def interactive_input(prompt=""):
        if prompt:
            sys.stdout.write(str(prompt))
            sys.stdout.flush()
        answer = PythonBridge.readLine()
        if answer == "\x00POCKETPYTHON_CANCEL":
            raise _StopExecution()
        return str(answer).rstrip("\r\n")

    user_builtins = dict(vars(builtins))
    user_builtins["input"] = interactive_input
    namespace = {
        "__name__": "__main__",
        "__file__": editor_filename,
        "__builtins__": user_builtins,
    }

    def cancellation_trace(frame, event, arg):
        if frame.f_code.co_filename == editor_filename and PythonBridge.isCancelled():
            raise _StopExecution()
        return cancellation_trace if frame.f_code.co_filename == editor_filename else None

    try:
        compiled = compile(source, editor_filename, "exec")
        sys.settrace(cancellation_trace)
        exec(compiled, namespace, namespace)
        return "completed"
    except _StopExecution:
        PythonBridge.write("\n[Execution stopped by user]\n")
        return "stopped"
    except SystemExit as exc:
        if exc.code not in (None, 0):
            PythonBridge.write(f"\n[Program exited with code: {exc.code}]\n")
        return "completed"
    except BaseException:
        traceback.print_exc(file=sys.stderr)
        return "error"
    finally:
        sys.settrace(old_trace)
        sys.stdout, sys.stderr = old_stdout, old_stderr
        os.chdir(old_cwd)
        sys.path[:] = old_path


def list_standard_library():
    """Return availability based on the embedded interpreter, not assumptions."""
    names = [
        "math", "random", "statistics", "decimal", "fractions", "datetime", "time",
        "calendar", "json", "csv", "re", "collections", "itertools", "functools",
        "pathlib", "os", "sys", "string", "sqlite3", "hashlib", "urllib", "unittest",
        "typing", "dataclasses", "enum", "heapq", "bisect", "operator", "copy", "pprint",
        "textwrap", "argparse", "configparser", "logging", "traceback", "tempfile", "shutil",
        "glob", "fnmatch", "subprocess", "threading", "queue", "asyncio", "inspect", "ast",
        "tokenize", "keyword", "io", "struct", "array", "weakref", "pickle", "shelve", "xml",
        "html", "email", "base64", "binascii", "uuid", "platform", "locale", "getpass",
        "zlib", "gzip", "bz2", "lzma", "zipfile", "tarfile", "secrets", "hmac", "ctypes",
        "multiprocessing", "venv", "ensurepip", "tkinter", "curses", "fcntl", "pty", "resource",
    ]
    result = []
    for name in names:
        try:
            available = importlib.util.find_spec(name) is not None
        except (ImportError, ValueError, AttributeError):
            available = False
        result.append({"name": name, "available": available})
    return json.dumps(result)


def refresh_package_imports(package_directory):
    """Make app-installed packages visible to subsequent Python imports."""
    directory = os.path.abspath(str(package_directory))
    os.makedirs(directory, exist_ok=True)
    # Put user-installed packages before stdlib/site paths, but avoid duplicate entries.
    while directory in sys.path:
        sys.path.remove(directory)
    sys.path.insert(0, directory)
    import importlib
    importlib.invalidate_caches()
    return json.dumps({"success": True, "package_directory": directory})


def search_package(name):
    """Look up an exact package name on PyPI; installing still checks Android wheel tags."""
    import urllib.error
    import urllib.parse
    import urllib.request
    package = str(name).strip()
    if not package or len(package) > 200:
        return json.dumps({"found": False, "message": "Enter a package name first."})
    url = "https://pypi.org/pypi/" + urllib.parse.quote(package, safe="") + "/json"
    request = urllib.request.Request(url, headers={"User-Agent": "PocketPython-Offline-IDE/0.1"})
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))
        info = data.get("info", {})
        return json.dumps({
            "found": True,
            "name": info.get("name", package),
            "version": info.get("version", "unknown"),
            "summary": info.get("summary", "")[:1000],
            "requires_python": info.get("requires_python", ""),
            "message": "Metadata found. Installation will still require compatible wheels for this Python/Android ABI.",
        })
    except urllib.error.HTTPError as exc:
        return json.dumps({"found": False, "message": "Package lookup failed with HTTP " + str(exc.code) + "."})
    except Exception as exc:
        return json.dumps({"found": False, "message": "Could not reach PyPI: " + str(exc)})
