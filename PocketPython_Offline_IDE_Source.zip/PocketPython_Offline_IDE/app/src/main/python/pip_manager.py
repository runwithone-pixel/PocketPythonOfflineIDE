"""Runtime package manager for compatible binary wheels only.

Uses the vendored pip CLI with --only-binary to avoid attempting native builds on Android.
All installed packages live in app-private persistent storage; wheel files are retained for
future offline reinstall. The active package directory is swapped only after success.
"""
import contextlib
import importlib.metadata
import io
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile

from pip._internal.cli.main import main as pip_main

try:
    from com.pocketpython.offline import PythonBridge
except Exception:  # pragma: no cover - developer testing fallback only
    class PythonBridge:
        @staticmethod
        def write(text):
            sys.__stdout__.write(text)


CHAQUOPY_INDEX = "https://chaquo.com/pypi-13.1/"
PYPI_INDEX = "https://pypi.org/simple"


def _pip(args, emit=True):
    capture = io.StringIO()
    try:
        with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
            status = int(pip_main(args) or 0)
    except BaseException as exc:
        status = 1
        capture.write(f"Package manager failed: {type(exc).__name__}: {exc}\n")
    output = capture.getvalue()
    if emit and output:
        PythonBridge.write(output[-18000:])
    return status, output


def _atomic_replace_directory(current_dir, staged_dir):
    parent = os.path.dirname(current_dir)
    backup = current_dir + ".previous"
    if os.path.exists(backup):
        shutil.rmtree(backup, ignore_errors=True)
    moved_current = False
    try:
        if os.path.exists(current_dir):
            os.replace(current_dir, backup)
            moved_current = True
        os.replace(staged_dir, current_dir)
        if moved_current:
            shutil.rmtree(backup, ignore_errors=True)
    except BaseException:
        if not os.path.exists(current_dir) and moved_current and os.path.exists(backup):
            os.replace(backup, current_dir)
        raise


def _run_install(requirement, site_dir, wheelhouse_dir, cache_dir, offline):
    requirement = str(requirement).strip()
    if not requirement or requirement.startswith("-"):
        return {"success": False, "message": "Enter a package name or version requirement, such as requests==2.32.5."}
    for path in (site_dir, wheelhouse_dir, cache_dir):
        os.makedirs(path, exist_ok=True)

    if not offline:
        # First check whether the complete dependency wheel set is already local. This avoids
        # requesting the network again when an exact install can be satisfied from cache.
        cached_stage = tempfile.mkdtemp(prefix="wheel-check-", dir=cache_dir)
        cached_args = [
            "download", "--disable-pip-version-check", "--no-input", "--no-index",
            "--find-links", wheelhouse_dir, "--only-binary=:all:", "--dest", cached_stage,
            requirement,
        ]
        cached_status, _ = _pip(cached_args, emit=False)
        if cached_status == 0:
            for item in os.listdir(cached_stage):
                source = os.path.join(cached_stage, item)
                if os.path.isfile(source) and item.endswith(".whl"):
                    shutil.copy2(source, os.path.join(wheelhouse_dir, item))
        shutil.rmtree(cached_stage, ignore_errors=True)
        if cached_status != 0:
            # Download wheels and all wheel dependencies first. No source distribution builds.
            download_args = [
                "download", "--disable-pip-version-check", "--no-input", "--only-binary=:all:",
                "--dest", wheelhouse_dir, "--cache-dir", cache_dir,
                "--extra-index-url", CHAQUOPY_INDEX,
                "--index-url", PYPI_INDEX,
                requirement,
            ]
            status, output = _pip(download_args)
            if status != 0:
                return {"success": False, "message": "No compatible wheel set could be downloaded. Check the package name, internet, Python 3.13 and Android ARM64 compatibility. Source builds are disabled deliberately.", "details": output[-2200:]}

    # pip must install in an isolated staging copy; the old site-packages stays intact on failure.
    parent = os.path.dirname(site_dir)
    staged = tempfile.mkdtemp(prefix="site-staging-", dir=parent)
    try:
        if os.path.isdir(site_dir):
            shutil.copytree(site_dir, staged, dirs_exist_ok=True)
        install_args = [
            "install", "--disable-pip-version-check", "--no-input", "--no-index",
            "--find-links", wheelhouse_dir, "--only-binary=:all:", "--upgrade",
            "--target", staged, "--cache-dir", cache_dir, requirement,
        ]
        status, output = _pip(install_args)
        if status != 0:
            return {"success": False, "message": "Offline install failed. One or more required compatible wheels may be missing from the local wheelhouse.", "details": output[-2200:]}
        _atomic_replace_directory(site_dir, staged)
        staged = ""
        import importlib
        importlib.invalidate_caches()
        return {"success": True, "message": f"Installed {requirement}. Compatible wheels are retained locally for offline use."}
    except BaseException as exc:
        return {"success": False, "message": f"Install transaction failed safely: {type(exc).__name__}: {exc}"}
    finally:
        if staged and os.path.isdir(staged):
            shutil.rmtree(staged, ignore_errors=True)


def install_online(requirement, site_dir, wheelhouse_dir, cache_dir):
    return json.dumps(_run_install(requirement, site_dir, wheelhouse_dir, cache_dir, False))


def install_offline(requirement, site_dir, wheelhouse_dir, cache_dir):
    return json.dumps(_run_install(requirement, site_dir, wheelhouse_dir, cache_dir, True))


def inspect_wheel(path):
    path = str(path)
    if not path.lower().endswith(".whl") or not zipfile.is_zipfile(path):
        return json.dumps({"valid": False, "message": "The selected file is not a valid .whl ZIP archive."})
    try:
        with zipfile.ZipFile(path) as archive:
            metadata_names = [n for n in archive.namelist() if n.endswith(".dist-info/METADATA")]
            if not metadata_names:
                return json.dumps({"valid": False, "message": "Wheel metadata is missing."})
            metadata = archive.read(metadata_names[0]).decode("utf-8", "replace")
            name = re.search(r"(?m)^Name:\s*(.+)$", metadata)
            version = re.search(r"(?m)^Version:\s*(.+)$", metadata)
            if not name or not version:
                return json.dumps({"valid": False, "message": "Wheel name/version metadata is incomplete."})
            file_name = os.path.basename(path)
            return json.dumps({
                "valid": True,
                "name": name.group(1).strip(),
                "version": version.group(1).strip(),
                "file": file_name,
                "note": "Compatibility will be checked by pip for this embedded CPython/Android ABI during installation.",
            })
    except (OSError, zipfile.BadZipFile, KeyError) as exc:
        return json.dumps({"valid": False, "message": f"Could not inspect wheel: {exc}"})


def add_wheel(source_path, wheelhouse_dir):
    source_path = str(source_path)
    wheelhouse_dir = str(wheelhouse_dir)
    info = json.loads(inspect_wheel(source_path))
    if not info.get("valid"):
        return json.dumps(info)
    os.makedirs(wheelhouse_dir, exist_ok=True)
    destination = os.path.join(wheelhouse_dir, info["file"])
    try:
        same_file = os.path.samefile(source_path, destination)
    except (OSError, FileNotFoundError):
        same_file = os.path.abspath(source_path) == os.path.abspath(destination)
    if not same_file:
        shutil.copy2(source_path, destination)
    info["cached_path"] = destination
    info["message"] = f"Added {info['name']} {info['version']} to the local wheelhouse. Use Offline Install to resolve all dependencies from cached wheels."
    return json.dumps(info)


def list_installed(site_dir):
    os.makedirs(site_dir, exist_ok=True)
    result = []
    try:
        distributions = importlib.metadata.distributions(path=[site_dir])
        seen = set()
        for dist in distributions:
            name = dist.metadata.get("Name") or "unknown"
            version = dist.version or "unknown"
            key = (name.lower(), version)
            if key in seen:
                continue
            seen.add(key)
            size = 0
            try:
                for file in dist.files or []:
                    path = dist.locate_file(file)
                    if os.path.isfile(path):
                        size += os.path.getsize(path)
            except OSError:
                pass
            license_name = (dist.metadata.get("License") or "").strip()
            if not license_name:
                license_fields = [item.split("::")[-1].strip() for item in dist.metadata.get_all("Classifier", []) if item.startswith("License ::")]
                license_name = ", ".join(license_fields[:2]) if license_fields else "Not declared in package metadata"
            result.append({"name": name, "version": version, "size_bytes": size, "license": license_name})
    except Exception as exc:
        return json.dumps({"error": str(exc), "packages": []})
    result.sort(key=lambda item: item["name"].lower())
    return json.dumps({"packages": result})


def uninstall_package(name, site_dir):
    name = str(name).strip()
    if not name or name.lower() in ("pip", "setuptools", "wheel"):
        return json.dumps({"success": False, "message": "This package cannot be uninstalled from the runtime manager."})
    site_dir = str(site_dir)
    parent = os.path.dirname(site_dir)
    staged = tempfile.mkdtemp(prefix="site-remove-", dir=parent)
    try:
        if os.path.isdir(site_dir):
            shutil.copytree(site_dir, staged, dirs_exist_ok=True)
        normalized = re.sub(r"[-_.]+", "_", name).lower()
        dist_dirs = []
        for entry in os.listdir(staged):
            if entry.endswith((".dist-info", ".egg-info")):
                meta = os.path.join(staged, entry, "METADATA")
                if not os.path.exists(meta):
                    meta = os.path.join(staged, entry, "PKG-INFO")
                try:
                    text = open(meta, encoding="utf-8", errors="replace").read()
                except OSError:
                    text = ""
                found = re.search(r"(?m)^Name:\s*(.+)$", text)
                if found and re.sub(r"[-_.]+", "_", found.group(1).strip()).lower() == normalized:
                    dist_dirs.append(entry)
        if not dist_dirs:
            return json.dumps({"success": False, "message": f"{name} was not found in app-installed packages."})
        for dist_dir in dist_dirs:
            metadata_dir = os.path.join(staged, dist_dir)
            top_level = os.path.join(metadata_dir, "top_level.txt")
            names = []
            try:
                names = [line.strip() for line in open(top_level, encoding="utf-8") if line.strip()]
            except OSError:
                names = [normalized.replace("-", "_")]
            shutil.rmtree(metadata_dir, ignore_errors=True)
            for module_name in names:
                candidate = os.path.join(staged, module_name)
                if os.path.isdir(candidate):
                    shutil.rmtree(candidate, ignore_errors=True)
                elif os.path.isfile(candidate):
                    os.remove(candidate)
        _atomic_replace_directory(site_dir, staged)
        staged = ""
        return json.dumps({"success": True, "message": f"Uninstalled {name}. Dependencies used by other packages were left in place."})
    except BaseException as exc:
        return json.dumps({"success": False, "message": f"Uninstall failed safely: {type(exc).__name__}: {exc}"})
    finally:
        if staged and os.path.isdir(staged):
            shutil.rmtree(staged, ignore_errors=True)


def import_and_install_wheel(source_path, site_dir, wheelhouse_dir, cache_dir):
    result = json.loads(add_wheel(source_path, wheelhouse_dir))
    if not result.get("valid"):
        return json.dumps(result)
    requirement = f"{result['name']}=={result['version']}"
    install_result = json.loads(install_offline(requirement, site_dir, wheelhouse_dir, cache_dir))
    result.update(install_result)
    return json.dumps(result)
