package com.pocketpython.offline

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import java.util.ArrayDeque

/** Lightweight native EditText code editor with a gutter and token colouring. */
class CodeEditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : EditText(context, attrs) {
    private val density = resources.displayMetrics.density
    private val gutterWidth = (66 * density).toInt()
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF748096.toInt()
        textSize = 12f * density
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.RIGHT
    }
    private val gutterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF242A35.toInt() }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF303847.toInt()
        strokeWidth = density
    }
    private var suppressCallbacks = false
    private var formatting = false
    private var beforeEdit = ""
    private var editStart = 0
    private var editBefore = 0
    private var editCount = 0
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private var lastEmittedText = ""
    var onCodeChanged: ((String) -> Unit)? = null
    var onCursorChanged: ((Int) -> Unit)? = null
    var editorFontSize: Float = 16f
        set(value) {
            field = value.coerceIn(12f, 28f)
            textSize = field
            invalidate()
        }
    var useWordWrap: Boolean = false
        set(value) {
            field = value
            setHorizontallyScrolling(!value)
            invalidate()
        }

    init {
        setTextColor(0xFFE6EAF2.toInt())
        setHintTextColor(0xFF778196.toInt())
        setBackgroundColor(0xFF151922.toInt())
        typeface = Typeface.MONOSPACE
        textSize = 16f
        gravity = android.view.Gravity.TOP or android.view.Gravity.START
        setPadding(gutterWidth + (12 * density).toInt(), (12 * density).toInt(), (16 * density).toInt(), (20 * density).toInt())
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_NONE
        isSingleLine = false
        setHorizontallyScrolling(true)
        setTextIsSelectable(true)

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                if (suppressCallbacks || formatting) return
                beforeEdit = s?.toString().orEmpty()
                editStart = start
                editBefore = count
                editCount = after
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (suppressCallbacks || formatting) return
                editStart = start
                editBefore = before
                editCount = count
            }

            override fun afterTextChanged(editable: Editable?) {
                if (suppressCallbacks || formatting || editable == null) return
                val inserted = if (editStart >= 0 && editStart + editCount <= editable.length) {
                    editable.substring(editStart, editStart + editCount)
                } else ""

                // Auto-indent only on a single newline (typing Enter), never on a multiline paste.
                if (inserted == "\n" && editCount == 1) {
                    val prior = editable.substring(0, editStart)
                    val previousLine = prior.substringAfterLast('\n')
                    val indent = previousLine.takeWhile { it == ' ' || it == '\t' }
                    val extra = if (previousLine.trimEnd().endsWith(":")) "    " else ""
                    val insertedIndent = indent + extra
                    if (insertedIndent.isNotEmpty()) {
                        formatting = true
                        editable.insert(editStart + 1, insertedIndent)
                        setSelection((editStart + 1 + insertedIndent.length).coerceAtMost(editable.length))
                        formatting = false
                    }
                } else if (inserted.length == 1) {
                    val closer = when (inserted[0]) {
                        '(' -> ")"
                        '[' -> "]"
                        '{' -> "}"
                        '\'' -> "'"
                        '"' -> "\""
                        else -> null
                    }
                    val cursor = selectionStart
                    if (closer != null && cursor == editStart + 1 && cursor <= editable.length) {
                        formatting = true
                        editable.insert(cursor, closer)
                        setSelection(cursor)
                        formatting = false
                    }
                }

                val now = editable.toString()
                if (now != beforeEdit) {
                    pushUndo(beforeEdit)
                    redoStack.clear()
                }
                lastEmittedText = now
                applyHighlighting(editable)
                invalidate()
                onCodeChanged?.invoke(now)
            }
        })
    }

    fun setCodeIfDifferent(value: String) {
        if (text?.toString() == value) return
        suppressCallbacks = true
        setText(value)
        val end = value.length.coerceAtMost(text?.length ?: 0)
        setSelection(end)
        lastEmittedText = value
        suppressCallbacks = false
        text?.let { applyHighlighting(it) }
        invalidate()
    }

    fun insertToolbarText(value: String) {
        val start = selectionStart.coerceAtLeast(0)
        val end = selectionEnd.coerceAtLeast(start)
        text?.replace(start, end, value)
        val cursor = if (value.length == 2 && value[0] in "([{\"'" && value[1] in ")]}'\"" ) start + 1 else start + value.length
        setSelection(cursor.coerceIn(0, text?.length ?: 0))
        requestFocus()
    }

    fun undoEdit() {
        if (undoStack.isEmpty()) return
        val current = text?.toString().orEmpty()
        redoStack.addLast(current)
        val target = undoStack.removeLast()
        setCodeIfDifferent(target)
        onCodeChanged?.invoke(target)
    }

    fun redoEdit() {
        if (redoStack.isEmpty()) return
        val current = text?.toString().orEmpty()
        undoStack.addLast(current)
        val target = redoStack.removeLast()
        setCodeIfDifferent(target)
        onCodeChanged?.invoke(target)
    }

    fun findNext(query: String, startAt: Int = selectionStart): Int {
        if (query.isEmpty()) return -1
        val source = text?.toString().orEmpty()
        var found = source.indexOf(query, startAt.coerceAtLeast(0), ignoreCase = false)
        if (found < 0 && startAt > 0) found = source.indexOf(query, 0, ignoreCase = false)
        if (found >= 0) {
            requestFocus()
            setSelection(found, found + query.length)
        }
        return found
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val textLayout = layout ?: return
        val saved = canvas.save()
        canvas.drawRect(0f, scrollY.toFloat(), gutterWidth.toFloat(), (scrollY + height).toFloat(), gutterPaint)
        canvas.drawLine(gutterWidth.toFloat(), scrollY.toFloat(), gutterWidth.toFloat(), (scrollY + height).toFloat(), dividerPaint)
        val first = textLayout.getLineForVertical(scrollY.coerceAtLeast(0))
        val last = textLayout.getLineForVertical((scrollY + height).coerceAtLeast(0))
        for (line in first..last) {
            if (line < 0 || line >= textLayout.lineCount) continue
            val baseline = textLayout.getLineBaseline(line) + compoundPaddingTop - scrollY
            canvas.drawText((line + 1).toString(), gutterWidth - (12 * density), baseline.toFloat(), numberPaint)
        }
        canvas.restoreToCount(saved)
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (selStart >= 0) onCursorChanged?.invoke(selStart)
        text?.let { applyHighlighting(it) }
        invalidate()
    }

    private fun pushUndo(value: String) {
        if (undoStack.peekLast() == value) return
        undoStack.addLast(value)
        while (undoStack.size > 120) undoStack.removeFirst()
    }

    private fun applyHighlighting(editable: Editable) {
        val spans = editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
        spans.forEach { editable.removeSpan(it) }
        val backgrounds = editable.getSpans(0, editable.length, BackgroundColorSpan::class.java)
        backgrounds.forEach { editable.removeSpan(it) }
        val source = editable.toString()
        val tokenRegex = Regex(
            "(?s)(''' .*? '''|\\\"\\\"\\\".*?\\\"\\\"\\\"|'(?:\\\\.|[^'\\\\])*'|\\\"(?:\\\\.|[^\\\"\\\\])*\\\"|#[^\\n]*|\\b(?:False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\\b|\\b(?:print|input|len|range|str|int|float|bool|list|dict|set|tuple|sum|min|max|enumerate|zip|open|type|super|self)\\b|\\b\\d+(?:\\.\\d+)?\\b)"
                .replace("''' .*? '''", "'''.*?'''")
        )
        tokenRegex.findAll(source).forEach { match ->
            val value = match.value
            val color = when {
                value.startsWith("#") -> 0xFF79B879.toInt()
                value.startsWith("'") || value.startsWith("\"") -> 0xFFE4B66A.toInt()
                value in PY_KEYWORDS -> 0xFFC792EA.toInt()
                value in PY_BUILTINS -> 0xFF82AAFF.toInt()
                value.firstOrNull()?.isDigit() == true -> 0xFFF78C6C.toInt()
                else -> 0xFFE6EAF2.toInt()
            }
            editable.setSpan(ForegroundColorSpan(color), match.range.first, match.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        // Highlight the bracket matching the character beside the caret, if present.
        val caret = selectionStart.coerceAtLeast(0)
        val positions = listOf(caret - 1, caret).filter { it in source.indices }
        val pairs = mapOf('(' to ')', '[' to ']', '{' to '}', ')' to '(', ']' to '[', '}' to '{')
        for (position in positions) {
            val ch = source[position]
            val target = pairs[ch] ?: continue
            var depth = 0
            val range = if (ch in "([{"
            ) {
                var found = -1
                for (i in position until source.length) {
                    if (source[i] == ch) depth++
                    if (source[i] == target) depth--
                    if (depth == 0) { found = i; break }
                }
                found
            } else {
                var found = -1
                for (i in position downTo 0) {
                    if (source[i] == ch) depth++
                    if (source[i] == target) depth--
                    if (depth == 0) { found = i; break }
                }
                found
            }
            if (range >= 0) {
                editable.setSpan(BackgroundColorSpan(0xFF38445A.toInt()), position, position + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                editable.setSpan(BackgroundColorSpan(0xFF38445A.toInt()), range, range + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                break
            }
        }
    }

    companion object {
        private val PY_KEYWORDS = setOf(
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue",
            "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import",
            "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"
        )
        private val PY_BUILTINS = setOf("print", "input", "len", "range", "str", "int", "float", "bool", "list", "dict", "set", "tuple", "sum", "min", "max", "enumerate", "zip", "open", "type", "super", "self")
    }
}
