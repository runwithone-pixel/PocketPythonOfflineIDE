package com.pocketpython.offline

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var ide: IDEState
    private var pendingExportText: String = ""
    private var pendingExportZip: File? = null

    private val importDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && ::ide.isInitialized) importDocumentUri(uri)
    }
    private val importWheel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && ::ide.isInitialized) importWheelUri(uri)
    }
    private val exportPython = registerForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri ->
        if (uri != null) writeTextUri(uri, pendingExportText)
    }
    private val exportZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val file = pendingExportZip
            if (file != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                    toast("Project ZIP exported")
                } catch (e: Exception) {
                    toast("Export failed: ${e.message ?: "storage error"}")
                } finally {
                    file.delete()
                    pendingExportZip = null
                }
            }
        } else {
            pendingExportZip?.delete()
            pendingExportZip = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 19, 25)
        window.navigationBarColor = android.graphics.Color.rgb(16, 19, 25)
        ide = IDEState(this)
        setContent { PocketPythonApp(ide, this) }
    }

    override fun onPause() {
        if (::ide.isInitialized) ide.flushAutosaveNow()
        super.onPause()
    }

    override fun onDestroy() {
        if (::ide.isInitialized) ide.dispose()
        super.onDestroy()
    }

    fun launchImportDocument() {
        importDocument.launch(arrayOf("text/*", "application/zip", "application/octet-stream", "application/x-python-code"))
    }

    fun launchImportWheel() {
        importWheel.launch(arrayOf("application/octet-stream", "application/zip", "*/*"))
    }

    fun launchExportPython() {
        pendingExportText = ide.code.value
        exportPython.launch(ide.currentFileName())
    }

    fun launchExportZip() {
        try {
            val zipFile = File(cacheDir, "${ide.currentProjectName()}-export.zip")
            ide.repo.createProjectZip(ide.currentProjectName(), zipFile)
            pendingExportZip = zipFile
            exportZip.launch("${ide.currentProjectName()}.zip")
        } catch (e: Exception) {
            toast("Could not prepare ZIP: ${e.message ?: "project error"}")
        }
    }

    private fun importDocumentUri(uri: Uri) {
        try {
            val name = getDisplayName(uri) ?: "imported.py"
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not read selected file")
            if (name.lowercase().endsWith(".zip")) {
                val target = File(cacheDir, "project-import-${System.currentTimeMillis()}.zip")
                input.use { source -> target.outputStream().use { source.copyTo(it) } }
                ide.importProjectArchive(target)
            } else if (name.lowercase().endsWith(".py")) {
                val source = input.bufferedReader(Charsets.UTF_8).use { it.readText() }
                ide.importPythonText(name, source)
            } else {
                input.close()
                toast("Choose a .py source file or project .zip")
            }
        } catch (e: Exception) {
            toast("Import failed: ${e.message ?: "file error"}")
        }
    }

    private fun importWheelUri(uri: Uri) {
        try {
            val name = getDisplayName(uri) ?: "package.whl"
            if (!name.lowercase().endsWith(".whl")) {
                toast("Choose a Python wheel file ending in .whl")
                return
            }
            val target = File(cacheDir, name.replace(Regex("[^A-Za-z0-9_.+-]"), "_"))
            contentResolver.openInputStream(uri)?.use { source -> target.outputStream().use { source.copyTo(it) } }
                ?: throw IllegalStateException("Could not read selected wheel")
            ide.installWheel(target)
        } catch (e: Exception) {
            toast("Wheel import failed: ${e.message ?: "file error"}")
        }
    }

    private fun writeTextUri(uri: Uri, text: String) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
            toast("Python file exported")
        } catch (e: Exception) {
            toast("Export failed: ${e.message ?: "storage error"}")
        }
    }

    private fun getDisplayName(uri: Uri): String? {
        var result: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) result = cursor.getString(index)
            }
        }
        return result ?: uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

private val DarkPalette = darkColorScheme(
    primary = Color(0xFF79D7B4),
    onPrimary = Color(0xFF09251C),
    secondary = Color(0xFF9AB7FF),
    background = Color(0xFF101319),
    onBackground = Color(0xFFE7EAF2),
    surface = Color(0xFF191E28),
    onSurface = Color(0xFFE7EAF2),
    surfaceVariant = Color(0xFF242B38),
    onSurfaceVariant = Color(0xFFBAC3D3),
    error = Color(0xFFFF8A80)
)
private val LightPalette = lightColorScheme(
    primary = Color(0xFF136C51),
    onPrimary = Color.White,
    secondary = Color(0xFF3B5DA8),
    background = Color(0xFFF4F6FA),
    onBackground = Color(0xFF17202A),
    surface = Color.White,
    onSurface = Color(0xFF17202A),
    surfaceVariant = Color(0xFFE8ECF3),
    onSurfaceVariant = Color(0xFF536071)
)

@Composable
private fun PocketPythonApp(state: IDEState, activity: MainActivity) {
    MaterialTheme(colorScheme = if (state.darkTheme.value) DarkPalette else LightPalette) {
        val scheme = MaterialTheme.colorScheme
        Surface(Modifier.fillMaxSize(), color = scheme.background) {
            IDEHome(state, activity)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IDEHome(state: IDEState, activity: MainActivity) {
    val context = LocalContext.current
    var editorRef by remember { mutableStateOf<CodeEditorView?>(null) }

    LaunchedEffect(Unit) { state.initialize() }
    LaunchedEffect(state.code.value, state.currentPath.value, state.isInitialized.value) {
        if (state.isInitialized.value) {
            delay(400)
            state.autosave(state.currentPath.value, state.code.value)
        }
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        // Top bar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("PocketPython", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text("OFFLINE-FIRST PYTHON IDE", fontSize = 10.sp, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            var menuExpanded by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { menuExpanded = true }) { Text("Menu  ⋮", fontWeight = FontWeight.SemiBold) }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("Files / Projects") }, onClick = { state.fileDialog.value = true; menuExpanded = false })
                    DropdownMenuItem(text = { Text("New Python file") }, onClick = { state.newFileDialog.value = true; menuExpanded = false })
                    DropdownMenuItem(text = { Text("New project") }, onClick = { state.newProjectDialog.value = true; menuExpanded = false })
                    DropdownMenuItem(text = { Text("Import / Open .py or ZIP") }, onClick = { activity.launchImportDocument(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Export current .py") }, onClick = { activity.launchExportPython(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Export project ZIP") }, onClick = { activity.launchExportZip(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Find / Replace") }, onClick = { state.findDialog.value = true; menuExpanded = false })
                    DropdownMenuItem(text = { Text("Library Manager") }, enabled = !state.isRunning.value, onClick = { state.openLibraryManager(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { state.settingsDialog.value = true; menuExpanded = false })
                }
            }
        }

        // File and save state
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(state.currentFileName(), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(state.currentPath.value, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(state.saveStatus.value, fontSize = 11.sp, color = if (state.saveStatus.value == "Saved") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Small editor toolbar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { editorRef?.undoEdit() }, enabled = !state.isRunning.value) { Text("Undo") }
            TextButton(onClick = { editorRef?.redoEdit() }, enabled = !state.isRunning.value) { Text("Redo") }
            TextButton(onClick = { state.findDialog.value = true }, enabled = !state.isRunning.value) { Text("Find") }
            Spacer(Modifier.weight(1f))
            Text("Python 3.13", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Editor occupies the flexible part of the screen and resizes around the keyboard.
        Card(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151922)),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (!state.isInitialized.value) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        CodeEditorView(ctx).also { view ->
                            view.editorFontSize = state.fontSize.value
                            view.useWordWrap = state.wordWrap.value
                            view.onCodeChanged = { newText -> state.onCodeChanged(newText) }
                            val cursor = state.cursorOffset.value
                            view.setCodeIfDifferent(state.code.value)
                            view.onCursorChanged = { offset -> state.onCursorChanged(offset) }
                            if (cursor >= 0) view.setSelection(cursor.coerceIn(0, view.text.length))
                            editorRef = view
                        }
                    },
                    update = { view ->
                        editorRef = view
                        view.editorFontSize = state.fontSize.value
                        view.useWordWrap = state.wordWrap.value
                        if (view.text?.toString() != state.code.value) {
                            val cursor = state.cursorOffset.value
                            view.setCodeIfDifferent(state.code.value)
                            if (cursor >= 0) view.setSelection(cursor.coerceIn(0, view.text.length))
                        }
                    }
                )
            }
        }

        // Touch insert strip. These buttons insert real characters at the cursor.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            listOf("()", "[]", "{}", ":", "=", "+", "-", "*", "/", "\"", "'", ",", "_").forEach { token ->
                Surface(
                    onClick = { editorRef?.insertToolbarText(token) },
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(token, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                }
            }
        }

        // Run/Stop and status
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { state.runProgram() },
                enabled = !state.isRunning.value && state.isInitialized.value,
                modifier = Modifier.weight(1f).height(46.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) { Text("▶  Run", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
            Button(
                onClick = { state.stopProgram() },
                enabled = state.isRunning.value,
                modifier = Modifier.width(100.dp).height(46.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8C3B43), disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) { Text("■ Stop") }
        }

        // Console panel: always in the same screen as the editor.
        Card(
            modifier = Modifier.fillMaxWidth().heightIn(min = if (state.awaitingInput.value) 155.dp else 120.dp, max = if (state.outputExpanded.value) 250.dp else 165.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Output", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    StatusChip(state.executionStatus.value)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { state.output.value = "" }) { Text("Clear") }
                    TextButton(onClick = { state.outputExpanded.value = !state.outputExpanded.value }) { Text(if (state.outputExpanded.value) "Less" else "More") }
                }
                Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text(
                        state.output.value.ifEmpty { "Run a program to see output here." },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                if (state.awaitingInput.value) {
                    var input by remember { mutableStateOf("") }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Type input() response") },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            label = { Text("Program input") }
                        )
                        Button(onClick = { state.submitConsoleInput(input); input = "" }) { Text("Send") }
                    }
                }
            }
        }
    }

    if (state.fileDialog.value) FileManagerDialog(state)
    if (state.newFileDialog.value) InputNameDialog("New Python file", "File name (e.g. lesson2.py)", "lesson.py", "Create", onDismiss = { state.newFileDialog.value = false }) { state.createNewFile(it) }
    if (state.newProjectDialog.value) InputNameDialog("New project", "Project name", "MyProject", "Create project", onDismiss = { state.newProjectDialog.value = false }) { state.createNewProject(it) }
    if (state.renameDialog.value) InputNameDialog("Rename file", "New file name", state.currentFileName(), "Rename", onDismiss = { state.renameDialog.value = false }) { state.renameCurrent(it) }
    if (state.deleteDialog.value) {
        AlertDialog(
            onDismissRequest = { state.deleteDialog.value = false },
            title = { Text("Delete ${state.currentFileName()}?") },
            text = { Text("This removes the file from app-private storage. Export a backup first if you need it.") },
            confirmButton = { TextButton(onClick = { state.deleteCurrent() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { state.deleteDialog.value = false }) { Text("Cancel") } }
        )
    }
    if (state.settingsDialog.value) SettingsDialog(state)
    if (state.findDialog.value) FindReplaceDialog(state, editorRef)
    if (state.libraryDialog.value) LibraryManagerDialog(state, activity)
    if (state.pendingUninstallName.value.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { state.pendingUninstallName.value = "" },
            title = { Text("Uninstall ${state.pendingUninstallName.value}?") },
            text = { Text("The package files will be removed. Dependencies are left in place, because other libraries may also need them.") },
            confirmButton = { TextButton(onClick = { state.uninstallPackage(state.pendingUninstallName.value) }) { Text("Uninstall") } },
            dismissButton = { TextButton(onClick = { state.pendingUninstallName.value = "" }) { Text("Cancel") } }
        )
    }
    if (state.pendingMessage.value.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { state.clearTransientMessage() },
            title = { Text("PocketPython") },
            text = { Text(state.pendingMessage.value) },
            confirmButton = { TextButton(onClick = { state.clearTransientMessage() }) { Text("OK") } }
        )
    }
}

@Composable
private fun StatusChip(status: String) {
    val color = when (status) {
        "Running" -> Color(0xFF407FBA)
        "Completed", "Saved", "Ready" -> MaterialTheme.colorScheme.primary
        "Error" -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(color = color.copy(alpha = 0.16f), contentColor = color, shape = RoundedCornerShape(30.dp)) {
        Text(status, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp), fontSize = 10.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FileManagerDialog(state: IDEState) {
    AlertDialog(
        onDismissRequest = { state.fileDialog.value = false },
        title = { Text("Files & Projects") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { state.fileDialog.value = false; state.newFileDialog.value = true }) { Text("+ File") }
                    TextButton(onClick = { state.fileDialog.value = false; state.newProjectDialog.value = true }) { Text("+ Project") }
                }
                Divider()
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    if (state.fileItems.value.isEmpty()) Text("No Python files yet.", modifier = Modifier.padding(12.dp))
                    state.fileItems.value.forEach { file ->
                        Surface(
                            onClick = { state.loadFile(file.relativePath) },
                            color = if (file.relativePath == state.currentPath.value) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(file.name, fontWeight = FontWeight.Medium)
                                    Text(file.relativePath, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(formatBytes(file.sizeBytes), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Divider()
                Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    TextButton(onClick = { state.fileDialog.value = false; state.renameDialog.value = true }) { Text("Rename") }
                    TextButton(onClick = { state.fileDialog.value = false; state.duplicateCurrent() }) { Text("Duplicate") }
                    TextButton(onClick = { state.fileDialog.value = false; state.deleteDialog.value = true }) { Text("Delete") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { state.fileDialog.value = false }) { Text("Done") } }
    )
}

@Composable
private fun InputNameDialog(title: String, label: String, initial: String, confirmText: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember(title, initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onConfirm(value.trim()) }) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SettingsDialog(state: IDEState) {
    AlertDialog(
        onDismissRequest = { state.settingsDialog.value = false },
        title = { Text("Editor Settings") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Dark theme", fontWeight = FontWeight.Medium)
                        Text("Light theme is also available", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Checkbox(checked = state.darkTheme.value, onCheckedChange = { state.setDarkTheme(it) })
                }
                Column {
                    Text("Editor font size: ${state.fontSize.value.toInt()} sp")
                    Slider(value = state.fontSize.value, onValueChange = { state.setFontSize(it) }, valueRange = 12f..28f)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Wrap long lines", fontWeight = FontWeight.Medium)
                        Text("Turn off to scroll horizontally", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Checkbox(checked = state.wordWrap.value, onCheckedChange = { state.setWordWrap(it) })
                }
                Text("Autosave: every 400 ms and on app pause", fontSize = 12.sp)
                Text("Projects stay in private app storage. Export backups before reinstalling or clearing app data.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { state.settingsDialog.value = false }) { Text("Done") } }
    )
}

@Composable
private fun FindReplaceDialog(state: IDEState, editor: CodeEditorView?) {
    var query by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { state.findDialog.value = false },
        title = { Text("Find / Replace") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Find") }, singleLine = true)
                OutlinedTextField(value = replacement, onValueChange = { replacement = it }, label = { Text("Replace with") }, singleLine = true)
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = { if (query.isNotEmpty()) editor?.findNext(query) }) { Text("Find next") }
                TextButton(onClick = {
                    if (query.isNotEmpty()) state.onCodeChanged(state.code.value.replace(query, replacement))
                    state.findDialog.value = false
                }) { Text("Replace all") }
            }
        },
        dismissButton = { TextButton(onClick = { state.findDialog.value = false }) { Text("Close") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryManagerDialog(state: IDEState, activity: MainActivity) {
    val tabs = listOf("Standard", "Installed", "Install")
    AlertDialog(
        onDismissRequest = { state.libraryDialog.value = false },
        title = {
            Column {
                Text("Library Manager")
                Text("Only compatible packages are installed; not all PyPI packages support Android.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    tabs.forEachIndexed { index, label ->
                        Surface(
                            onClick = { state.libraryTab.value = index },
                            color = if (state.libraryTab.value == index) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), fontWeight = if (state.libraryTab.value == index) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                when (state.libraryTab.value) {
                    0 -> StandardLibraryList(state)
                    1 -> InstalledPackageList(state)
                    else -> InstallPackagePanel(state, activity)
                }
            }
        },
        confirmButton = { TextButton(onClick = { state.libraryDialog.value = false }) { Text("Close") } }
    )
}

@Composable
private fun StandardLibraryList(state: IDEState) {
    val modules = remember(state.standardModulesJson.value) {
        runCatching {
            val array = JSONArray(state.standardModulesJson.value)
            (0 until array.length()).map { array.getJSONObject(it) }
        }.getOrDefault(emptyList())
    }
    Column(Modifier.fillMaxWidth().heightIn(max = 370.dp).verticalScroll(rememberScrollState())) {
        Text("Checked against the interpreter at runtime.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        modules.forEach { item ->
            val name = item.optString("name")
            val available = item.optBoolean("available")
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text(if (available) "Available" else "Unavailable", fontSize = 10.sp, color = if (available) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun InstalledPackageList(state: IDEState) {
    val json = remember(state.installedPackagesJson.value) { runCatching { JSONObject(state.installedPackagesJson.value) }.getOrNull() }
    val packages = remember(state.installedPackagesJson.value) {
        runCatching {
            val array = JSONObject(state.installedPackagesJson.value).optJSONArray("packages") ?: JSONArray()
            (0 until array.length()).map { array.getJSONObject(it) }
        }.getOrDefault(emptyList())
    }
    Column(Modifier.fillMaxWidth().heightIn(max = 370.dp).verticalScroll(rememberScrollState())) {
        Text("Packages in private storage · ${packages.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (packages.isEmpty()) Text("No third-party packages installed in app storage yet.", modifier = Modifier.padding(vertical = 12.dp), fontSize = 12.sp)
        packages.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.optString("name"), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    Text("v${item.optString("version")} · ${formatBytes(item.optLong("size_bytes"))}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("License: ${item.optString("license", "not reported")}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { state.pendingUninstallName.value = item.optString("name") }, enabled = !state.packageBusy.value) { Text("Remove") }
            }
            Divider(color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}

@Composable
private fun InstallPackagePanel(state: IDEState, activity: MainActivity) {
    Column(Modifier.fillMaxWidth().heightIn(max = 390.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Search an exact package name, then install compatible wheels. Native builds from source are disabled.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = state.packageQuery.value,
            onValueChange = { state.packageQuery.value = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Package or requirement") },
            placeholder = { Text("requests or sympy==1.14.0") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Search)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { state.searchPackage() }, enabled = !state.packageBusy.value, modifier = Modifier.weight(1f)) { Text("Search online") }
            Button(onClick = { state.installPackage(false) }, enabled = !state.packageBusy.value, modifier = Modifier.weight(1f)) { Text("Install online") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { state.installPackage(true) }, enabled = !state.packageBusy.value, modifier = Modifier.weight(1f)) { Text("Install offline") }
            Button(onClick = { activity.launchImportWheel() }, enabled = !state.packageBusy.value, modifier = Modifier.weight(1f)) { Text("Import .whl") }
        }
        if (state.packageBusy.value) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            Text("Working…", fontSize = 12.sp)
        }
        if (state.packageSearchResult.value.isNotBlank()) {
            val result = remember(state.packageSearchResult.value) { runCatching { JSONObject(state.packageSearchResult.value) }.getOrNull() }
            if (result?.optBoolean("found") == true) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                        Text("${result.optString("name")}  ${result.optString("version")}", fontWeight = FontWeight.Bold)
                        Text(result.optString("summary"), fontSize = 12.sp)
                        Text("Requires Python: ${result.optString("requires_python", "not specified")}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Text(state.packageStatus.value.ifBlank { "Package installs are explicit and optional. Previously installed packages remain available offline." }, fontSize = 12.sp)
        Text("Offline install uses the local wheelhouse. If any dependency wheel is missing or incompatible, installation fails without replacing the existing package directory.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> "${bytes / (1024 * 1024)} MB"
}
