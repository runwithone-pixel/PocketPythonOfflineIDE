package com.pocketpython.offline

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Persistent, app-private source storage. Paths exposed to UI are relative to projects/. */
class ProjectRepository(context: Context) {
    private val appContext = context.applicationContext
    val root = File(appContext.filesDir, "projects").apply { mkdirs() }
    val packageDir = File(appContext.filesDir, "python-packages/site-packages").apply { mkdirs() }
    val wheelhouseDir = File(appContext.filesDir, "python-packages/wheelhouse").apply { mkdirs() }
    val packageCacheDir = File(appContext.cacheDir, "pip-cache").apply { mkdirs() }
    private val prefs = appContext.getSharedPreferences("pocketpython", Context.MODE_PRIVATE)

    data class SourceFile(val relativePath: String, val name: String, val project: String, val sizeBytes: Long)

    @Synchronized
    fun ensureStarter(): String {
        root.mkdirs()
        val last = prefs.getString("last_file", null)
        if (!last.isNullOrBlank() && resolve(last).isFile) return last
        val starterDir = File(root, "StarterProject").apply { mkdirs() }
        val starter = File(starterDir, "main.py")
        if (!starter.exists()) {
            writeAtomic(starter, """# Welcome to PocketPython Offline IDE!
name = input("Enter your name: ")
print(f"Hello, {name}!")

# Try editing this program, then tap Run.
""")
        }
        prefs.edit().putString("last_file", "StarterProject/main.py").apply()
        return "StarterProject/main.py"
    }

    fun lastFile(): String = prefs.getString("last_file", "StarterProject/main.py") ?: "StarterProject/main.py"

    fun setLastFile(relativePath: String) {
        prefs.edit().putString("last_file", relativePath).apply()
    }

    fun resolve(relativePath: String): File {
        val clean = sanitizeRelativePath(relativePath)
        val target = File(root, clean).canonicalFile
        require(target.path == root.canonicalPath || target.path.startsWith(root.canonicalPath + File.separator)) {
            "Invalid project path"
        }
        return target
    }

    fun read(relativePath: String): String {
        val file = resolve(relativePath)
        val checkpoint = recoveryFile(relativePath)
        if (checkpoint.isFile) {
            val recoveryText = runCatching { checkpoint.readText(Charsets.UTF_8) }.getOrNull()
            val mainText = if (file.isFile) runCatching { file.readText(Charsets.UTF_8) }.getOrNull() else null
            // The checkpoint is written first. If contents differ, the app may have been
            // interrupted between checkpoint commit and the main-file commit.
            if (recoveryText != null && recoveryText != mainText) {
                file.parentFile?.mkdirs()
                writeAtomic(file, recoveryText)
                return recoveryText
            }
        }
        if (!file.isFile) return checkpoint.takeIf { it.isFile }?.readText(Charsets.UTF_8) ?: ""
        return file.readText(Charsets.UTF_8)
    }

    @Synchronized
    fun save(relativePath: String, source: String) {
        val file = resolve(relativePath)
        file.parentFile?.mkdirs()
        // Keep a separate durable recovery checkpoint until a later save commits safely.
        writeAtomic(recoveryFile(relativePath), source)
        writeAtomic(file, source)
        setLastFile(relativePath)
    }

    @Synchronized
    fun saveIfLatest(relativePath: String, source: String, stillLatest: () -> Boolean): Boolean {
        if (!stillLatest()) return false
        val file = resolve(relativePath)
        file.parentFile?.mkdirs()
        writeAtomic(recoveryFile(relativePath), source)
        writeAtomic(file, source)
        setLastFile(relativePath)
        return true
    }

    @Synchronized
    fun createFile(projectName: String, requestedFileName: String, source: String = "# Start coding in Python\n"): String {
        val project = safeName(projectName, "MyProject")
        var filename = safeName(requestedFileName.substringBeforeLast('.', requestedFileName), "main") + ".py"
        val dir = File(root, project).apply { mkdirs() }
        var target = File(dir, filename)
        var suffix = 2
        while (target.exists()) {
            filename = "${safeName(requestedFileName.substringBeforeLast('.', requestedFileName), "main")}_$suffix.py"
            target = File(dir, filename)
            suffix++
        }
        recoveryFile("$project/$filename").delete()
        writeAtomic(target, source)
        val rel = "$project/$filename"
        setLastFile(rel)
        return rel
    }

    @Synchronized
    fun createProject(projectName: String, source: String = "# ${projectName}\n"): String {
        val project = safeName(projectName, "MyProject")
        val dir = File(root, project)
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Could not create project folder")
        val file = File(dir, "main.py")
        if (file.exists()) throw IllegalArgumentException("A project with this name already has main.py")
        recoveryFile("$project/main.py").delete()
        writeAtomic(file, source)
        val rel = "$project/main.py"
        setLastFile(rel)
        return rel
    }

    fun listFiles(): List<SourceFile> {
        root.mkdirs()
        val result = mutableListOf<SourceFile>()
        root.walkTopDown().filter { it.isFile && it.extension.equals("py", true) }.forEach { file ->
            val rel = file.absolutePath.removePrefix(root.absolutePath.trimEnd(File.separatorChar) + File.separator).replace(File.separatorChar, '/')
            result += SourceFile(rel, file.name, file.parentFile?.name ?: "Project", file.length())
        }
        return result.sortedBy { it.relativePath.lowercase() }
    }

    @Synchronized
    fun rename(relativePath: String, newFileName: String): String {
        val old = resolve(relativePath)
        require(old.isFile) { "File does not exist" }
        var base = safeName(newFileName.substringBeforeLast('.', newFileName), "main") + ".py"
        val newFile = File(old.parentFile, base)
        require(!newFile.exists() || newFile.canonicalFile == old.canonicalFile) { "A file with that name already exists" }
        if (newFile.canonicalFile != old.canonicalFile && !old.renameTo(newFile)) throw IllegalStateException("Rename failed")
        val rel = newFile.absolutePath.removePrefix(root.absolutePath.trimEnd(File.separatorChar) + File.separator).replace(File.separatorChar, '/')
        setLastFile(rel)
        return rel
    }

    @Synchronized
    fun duplicate(relativePath: String): String {
        val old = resolve(relativePath)
        require(old.isFile) { "File does not exist" }
        return createFile(old.parentFile.name, old.nameWithoutExtension + "_copy", old.readText(Charsets.UTF_8))
    }

    @Synchronized
    fun delete(relativePath: String) {
        val file = resolve(relativePath)
        if (file.exists() && !file.delete()) throw IllegalStateException("Delete failed")
        recoveryFile(relativePath).delete()
        file.parentFile?.let { dir -> if (dir.isDirectory && dir.listFiles().isNullOrEmpty()) dir.delete() }
        if (lastFile() == relativePath) {
            val next = listFiles().firstOrNull()?.relativePath
            if (next != null) setLastFile(next) else ensureStarter()
        }
    }

    fun currentDirectory(relativePath: String): File {
        val file = resolve(relativePath)
        return file.parentFile ?: root
    }

    fun createProjectZip(projectName: String, destination: File) {
        val projectRoot = File(root, safeName(projectName, "StarterProject"))
        require(projectRoot.isDirectory) { "Project not found" }
        ZipOutputStream(BufferedOutputStream(FileOutputStream(destination))).use { zip ->
            projectRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                val rel = file.absolutePath.removePrefix(projectRoot.absolutePath.trimEnd(File.separatorChar) + File.separator).replace(File.separatorChar, '/')
                zip.putNextEntry(ZipEntry("${projectRoot.name}/$rel"))
                BufferedInputStream(FileInputStream(file)).use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    @Synchronized
    fun importProjectZip(source: File): String {
        // Extract only .py files into a new, collision-free project folder. Never overwrite
        // an existing project and reject traversal/absolute archive entries.
        val firstEntry = java.util.zip.ZipFile(source).use { zip ->
            val first = zip.entries().asSequence().firstOrNull { !it.isDirectory && it.name.endsWith(".py", true) }
            first?.name
        } ?: throw IllegalArgumentException("The ZIP has no .py source files")
        val firstPath = firstEntry.replace('\\', '/').split('/').filter { it.isNotBlank() }
        require(firstPath.none { it == ".." || it == "." }) { "Unsafe ZIP path" }
        val requestedProject = if (firstPath.size > 1) firstPath.first() else "ImportedProject"
        var projectName = safeName(requestedProject, "ImportedProject")
        var suffix = 2
        while (File(root, projectName).exists()) {
            projectName = "${safeName(requestedProject, "ImportedProject")}_$suffix"
            suffix++
        }
        val projectDir = File(root, projectName).apply { mkdirs() }
        var firstImported: String? = null
        try {
            ZipInputStream(BufferedInputStream(FileInputStream(source))).use { zip ->
                var entry: ZipEntry? = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    val components = name.split('/').filter { it.isNotBlank() }
                    require(!name.startsWith('/') && components.none { it == ".." || it == "." }) { "Unsafe ZIP path" }
                    if (entry.isDirectory) {
                        zip.closeEntry()
                        entry = zip.nextEntry
                        continue
                    }
                    if (name.endsWith(".py", true)) {
                        val relativeParts = if (components.size > 1) components.drop(1) else components
                        if (relativeParts.isNotEmpty()) {
                            val safeParts = relativeParts.map { safeName(it, "main.py") }
                            val output = File(projectDir, safeParts.joinToString(File.separator))
                            val canonical = output.canonicalFile
                            require(canonical.path.startsWith(projectDir.canonicalPath + File.separator)) { "Unsafe ZIP path" }
                            output.parentFile?.mkdirs()
                            writeAtomic(output, zip.readBytes().toString(Charsets.UTF_8))
                            if (firstImported == null) {
                                firstImported = "$projectName/" + safeParts.joinToString("/")
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val result = firstImported ?: throw IllegalArgumentException("The ZIP has no importable .py files")
            setLastFile(result)
            return result
        } catch (t: Throwable) {
            projectDir.deleteRecursively()
            throw t
        }
    }

    fun rememberFontSize(size: Float) = prefs.edit().putFloat("font_size", size.coerceIn(12f, 28f)).apply()
    fun fontSize(): Float = prefs.getFloat("font_size", 16f).coerceIn(12f, 28f)
    fun rememberDarkTheme(dark: Boolean) = prefs.edit().putBoolean("dark_theme", dark).apply()
    fun darkTheme(): Boolean = prefs.getBoolean("dark_theme", true)
    fun rememberWordWrap(enabled: Boolean) = prefs.edit().putBoolean("word_wrap", enabled).apply()
    fun wordWrap(): Boolean = prefs.getBoolean("word_wrap", false)

    fun packageRecordsFile(): File = File(appContext.filesDir, "python-packages/installed-packages.json")

    fun rememberCursor(relativePath: String, offset: Int) {
        prefs.edit().putInt("cursor_${pathKey(relativePath)}", offset.coerceAtLeast(0)).apply()
    }

    fun cursorOffset(relativePath: String): Int = prefs.getInt("cursor_${pathKey(relativePath)}", -1)

    private fun recoveryFile(relativePath: String): File {
        val directory = File(appContext.filesDir, "recovery").apply { mkdirs() }
        return File(directory, pathKey(relativePath) + ".checkpoint")
    }

    private fun pathKey(value: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun writeAtomic(file: File, content: String) {
        val atomic = AtomicFile(file)
        var output: FileOutputStream? = null
        try {
            output = atomic.startWrite()
            output.write(content.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (t: Throwable) {
            if (output != null) atomic.failWrite(output)
            throw t
        }
    }

    private fun sanitizeRelativePath(value: String): String {
        val clean = value.replace('\\', '/').trimStart('/')
        require(clean.isNotBlank() && !clean.split('/').any { it == ".." || it == "." }) { "Invalid project path" }
        require(clean.endsWith(".py", ignoreCase = true)) { "Only .py files are editable" }
        return clean
    }

    private fun safeName(value: String, fallback: String): String {
        val cleaned = value.trim().replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_')
        return cleaned.take(64).ifBlank { fallback }
    }
}
