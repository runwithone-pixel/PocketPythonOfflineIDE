package com.pocketpython.offline

import android.content.Context
import com.chaquo.python.Python
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf

class IDEState(private val context: Context) {
    val repo = ProjectRepository(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val isRunningFlag = AtomicBoolean(false)

    val code: MutableState<String> = mutableStateOf("")
    val currentPath: MutableState<String> = mutableStateOf("StarterProject/main.py")
    val saveStatus: MutableState<String> = mutableStateOf("Loading…")
    val executionStatus: MutableState<String> = mutableStateOf("Ready")
    val output: MutableState<String> = mutableStateOf("PocketPython is ready. Your code stays on this device.\n")
    val isInitialized = mutableStateOf(false)
    val isRunning = mutableStateOf(false)
    val awaitingInput = mutableStateOf(false)
    val outputExpanded = mutableStateOf(true)
    val darkTheme = mutableStateOf(repo.darkTheme())
    val fontSize = mutableStateOf(repo.fontSize())
    val wordWrap = mutableStateOf(repo.wordWrap())
    val cursorOffset = mutableStateOf(-1)
    val fileItems = mutableStateOf(emptyList<ProjectRepository.SourceFile>())
    val libraryDialog = mutableStateOf(false)
    val settingsDialog = mutableStateOf(false)
    val fileDialog = mutableStateOf(false)
    val newFileDialog = mutableStateOf(false)
    val newProjectDialog = mutableStateOf(false)
    val renameDialog = mutableStateOf(false)
    val deleteDialog = mutableStateOf(false)
    val findDialog = mutableStateOf(false)
    val pendingMessage = mutableStateOf("")
    val outputError = mutableStateOf("")

    val libraryTab = mutableStateOf(0)
    val packageQuery = mutableStateOf("")
    val packageSearchResult = mutableStateOf("")
    val packageStatus = mutableStateOf("")
    val packageBusy = mutableStateOf(false)
    val standardModulesJson = mutableStateOf("[]")
    val installedPackagesJson = mutableStateOf("{\"packages\":[]}")
    val pendingUninstallName = mutableStateOf("")

    @Volatile private var editorCodeSnapshot = ""
    @Volatile private var editorPathSnapshot = "StarterProject/main.py"

    fun initialize() {
        if (isInitialized.value) return
        scope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) {
                    val path = repo.ensureStarter()
                    path to repo.read(path)
                }
                currentPath.value = loaded.first
                currentPath.value.let { editorPathSnapshot = it }
                code.value = loaded.second
                editorCodeSnapshot = loaded.second
                cursorOffset.value = repo.cursorOffset(loaded.first)
                refreshFiles()
                isInitialized.value = true
                saveStatus.value = "Saved"
                output.value = "PocketPython Offline IDE · Python runtime starting on first Run.\n"
            } catch (e: Exception) {
                saveStatus.value = "Recovery needed"
                pendingMessage.value = "Could not open the last project: ${e.message ?: "unknown storage error"}"
                isInitialized.value = true
            }
        }
    }

    fun onCodeChanged(value: String) {
        code.value = value
        editorCodeSnapshot = value
    }

    fun onCursorChanged(offset: Int) {
        cursorOffset.value = offset
        if (isInitialized.value) repo.rememberCursor(currentPath.value, offset)
    }

    fun flushAutosaveNow() {
        if (!isInitialized.value) return
        try {
            val path = currentPath.value
            val source = code.value
            repo.save(path, source)
            editorPathSnapshot = path
            editorCodeSnapshot = source
            saveStatus.value = "Saved"
        } catch (e: Exception) {
            saveStatus.value = "Save error"
            pendingMessage.value = "Emergency save failed: ${e.message ?: "storage error"}"
        }
    }

    fun autosave(path: String, source: String) {
        if (!isInitialized.value) return
        editorCodeSnapshot = source
        editorPathSnapshot = path
        scope.launch {
            saveStatus.value = "Saving…"
            try {
                val committed = withContext(Dispatchers.IO) {
                    repo.saveIfLatest(path, source) { editorPathSnapshot == path && editorCodeSnapshot == source }
                }
                if (committed && editorPathSnapshot == path && editorCodeSnapshot == source) saveStatus.value = "Saved"
            } catch (e: Exception) {
                saveStatus.value = "Save error"
                pendingMessage.value = "Autosave failed: ${e.message ?: "storage error"}. Export your code before leaving this screen."
            }
        }
    }

    suspend fun saveNow(): Boolean = withContext(Dispatchers.IO) {
        try {
            repo.save(currentPath.value, code.value)
            withContext(Dispatchers.Main) { saveStatus.value = "Saved" }
            true
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                saveStatus.value = "Save error"
                pendingMessage.value = "Could not save before execution: ${e.message ?: "storage error"}"
            }
            false
        }
    }

    fun loadFile(path: String) {
        scope.launch {
            try {
                saveNow()
                val source = withContext(Dispatchers.IO) { repo.read(path) }
                currentPath.value = path
                editorPathSnapshot = path
                code.value = source
                editorCodeSnapshot = source
                cursorOffset.value = repo.cursorOffset(path)
                repo.setLastFile(path)
                refreshFiles()
                fileDialog.value = false
                saveStatus.value = "Saved"
            } catch (e: Exception) {
                pendingMessage.value = "Could not open file: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun refreshFiles() {
        scope.launch { fileItems.value = withContext(Dispatchers.IO) { repo.listFiles() } }
    }

    fun createNewFile(fileName: String) {
        scope.launch {
            try {
                saveNow()
                val projectName = currentPath.value.substringBefore('/')
                val rel = withContext(Dispatchers.IO) { repo.createFile(projectName, fileName) }
                currentPath.value = rel
                code.value = repo.read(rel)
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                editorCodeSnapshot = code.value
                refreshFiles()
                newFileDialog.value = false
                pendingMessage.value = "Created $rel"
            } catch (e: Exception) {
                pendingMessage.value = "Could not create file: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun createNewProject(projectName: String) {
        scope.launch {
            try {
                saveNow()
                val rel = withContext(Dispatchers.IO) { repo.createProject(projectName) }
                currentPath.value = rel
                code.value = repo.read(rel)
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                editorCodeSnapshot = code.value
                refreshFiles()
                newProjectDialog.value = false
                pendingMessage.value = "Created project ${rel.substringBefore('/')}"
            } catch (e: Exception) {
                pendingMessage.value = "Could not create project: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun renameCurrent(newName: String) {
        scope.launch {
            try {
                saveNow()
                val old = currentPath.value
                val rel = withContext(Dispatchers.IO) { repo.rename(old, newName) }
                currentPath.value = rel
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                repo.save(rel, code.value)
                refreshFiles()
                renameDialog.value = false
                pendingMessage.value = "Renamed to ${rel.substringAfterLast('/')}"
            } catch (e: Exception) {
                pendingMessage.value = "Rename failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun duplicateCurrent() {
        scope.launch {
            try {
                saveNow()
                val rel = withContext(Dispatchers.IO) {
                    repo.save(currentPath.value, code.value)
                    repo.duplicate(currentPath.value)
                }
                currentPath.value = rel
                code.value = repo.read(rel)
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                editorCodeSnapshot = code.value
                refreshFiles()
                pendingMessage.value = "Duplicated to $rel"
            } catch (e: Exception) {
                pendingMessage.value = "Duplicate failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun deleteCurrent() {
        scope.launch {
            try {
                val deletedPath = currentPath.value
                withContext(Dispatchers.IO) { repo.delete(deletedPath) }
                val next = repo.lastFile()
                currentPath.value = next
                code.value = withContext(Dispatchers.IO) { repo.read(next) }
                cursorOffset.value = repo.cursorOffset(next)
                editorPathSnapshot = next
                editorCodeSnapshot = code.value
                refreshFiles()
                deleteDialog.value = false
                pendingMessage.value = "Deleted $deletedPath"
            } catch (e: Exception) {
                pendingMessage.value = "Delete failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun importPythonText(name: String, source: String) {
        scope.launch {
            try {
                saveNow()
                val projectName = currentPath.value.substringBefore('/')
                val rel = withContext(Dispatchers.IO) { repo.createFile(projectName, name, source) }
                currentPath.value = rel
                code.value = withContext(Dispatchers.IO) { repo.read(rel) }
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                editorCodeSnapshot = code.value
                refreshFiles()
                pendingMessage.value = "Imported $rel"
            } catch (e: Exception) {
                pendingMessage.value = "Import failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun importProjectArchive(tempZip: File) {
        scope.launch {
            try {
                val rel = withContext(Dispatchers.IO) { repo.importProjectZip(tempZip) }
                currentPath.value = rel
                code.value = withContext(Dispatchers.IO) { repo.read(rel) }
                cursorOffset.value = repo.cursorOffset(rel)
                editorPathSnapshot = rel
                editorCodeSnapshot = code.value
                refreshFiles()
                pendingMessage.value = "Project ZIP imported. Current file: $rel"
            } catch (e: Exception) {
                pendingMessage.value = "Project ZIP import failed: ${e.message ?: "invalid archive"}"
            } finally {
                tempZip.delete()
            }
        }
    }

    fun runProgram() {
        if (!isRunningFlag.compareAndSet(false, true)) return
        val runSource = code.value
        val runPath = currentPath.value
        scope.launch {
            try {
                // Save and execute the exact same immutable source snapshot.
                withContext(Dispatchers.IO) { repo.save(runPath, runSource) }
                saveStatus.value = "Saved"
                output.value = ""
                awaitingInput.value = false
                executionStatus.value = "Running"
                isRunning.value = true
                PythonBridge.reset()
                PythonBridge.attach(object : PythonBridge.Listener {
                    override fun onOutput(text: String) {
                        scope.launch(Dispatchers.Main.immediate) {
                            val combined = output.value + text
                            output.value = if (combined.length > 50_000) combined.takeLast(50_000) else combined
                        }
                    }
                    override fun onInputRequested() {
                        scope.launch(Dispatchers.Main.immediate) { awaitingInput.value = true }
                    }
                })

                val result = withContext(Dispatchers.IO) {
                    val python = Python.getInstance()
                    val runner = python.getModule("runner")
                    val currentFile = repo.resolve(runPath).absolutePath
                    runner.callAttr(
                        "run_code", runSource,
                        repo.currentDirectory(runPath).absolutePath,
                        repo.packageDir.absolutePath,
                        currentFile
                    ).toString()
                }
                executionStatus.value = when (result) {
                    "completed" -> "Completed"
                    "stopped" -> "Stopped"
                    else -> "Error"
                }
            } catch (e: Exception) {
                appendOutput("\nRuntime startup error: ${e.message ?: e.javaClass.simpleName}\n")
                executionStatus.value = "Error"
            } finally {
                awaitingInput.value = false
                isRunning.value = false
                isRunningFlag.set(false)
                PythonBridge.detach()
            }
        }
    }

    fun stopProgram() {
        if (!isRunning.value) return
        executionStatus.value = "Stopping…"
        PythonBridge.cancel()
        // Also changes the visible status immediately; the runtime confirms when it returns.
    }

    fun submitConsoleInput(value: String) {
        if (!awaitingInput.value) return
        appendOutput(value + "\n") // Echo input like a normal console.
        awaitingInput.value = false
        PythonBridge.submitInput(value)
    }

    private fun appendOutput(text: String) {
        scope.launch(Dispatchers.Main.immediate) {
            val combined = output.value + text
            output.value = if (combined.length > 50_000) combined.takeLast(50_000) else combined
        }
    }

    fun openLibraryManager() {
        libraryDialog.value = true
        refreshInstalledPackages()
        scope.launch {
            try {
                val json = withContext(Dispatchers.IO) {
                    Python.getInstance().getModule("runner").callAttr("list_standard_library").toString()
                }
                standardModulesJson.value = json
            } catch (e: Exception) {
                packageStatus.value = "Could not query interpreter modules: ${e.message}"
            }
        }
    }

    fun refreshInstalledPackages() {
        scope.launch {
            try {
                installedPackagesJson.value = withContext(Dispatchers.IO) {
                    Python.getInstance().getModule("pip_manager").callAttr("list_installed", repo.packageDir.absolutePath).toString()
                }
            } catch (e: Exception) {
                installedPackagesJson.value = "{\"packages\":[],\"error\":${JSONObject.quote(e.message ?: "Runtime unavailable")}}"
            }
        }
    }

    fun searchPackage() {
        val query = packageQuery.value.trim()
        if (query.isBlank()) {
            packageStatus.value = "Type an exact package name, for example sympy."
            return
        }
        packageBusy.value = true
        packageStatus.value = "Searching PyPI…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    Python.getInstance().getModule("runner").callAttr("search_package", query).toString()
                }
                packageSearchResult.value = result
                val json = JSONObject(result)
                packageStatus.value = if (json.optBoolean("found")) "Found ${json.optString("name")} ${json.optString("version")}" else json.optString("message", "Package not found")
            } catch (e: Exception) {
                packageStatus.value = "Package search failed: ${e.message ?: "network error"}"
            } finally {
                packageBusy.value = false
            }
        }
    }

    fun installPackage(offline: Boolean) {
        val query = packageQuery.value.trim()
        if (query.isBlank()) {
            packageStatus.value = "Enter a package name or version first."
            return
        }
        packageBusy.value = true
        packageStatus.value = if (offline) "Resolving packages from the local wheelhouse…" else "Downloading compatible wheels and dependencies…"
        PythonBridge.reset()
        PythonBridge.attach(object : PythonBridge.Listener {
            override fun onOutput(text: String) { scope.launch(Dispatchers.Main.immediate) { packageStatus.value = text.takeLast(1200) } }
            override fun onInputRequested() { }
        })
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val python = Python.getInstance()
                    val module = python.getModule("pip_manager")
                    val attr = if (offline) "install_offline" else "install_online"
                    val output = module.callAttr(
                        attr, query, repo.packageDir.absolutePath,
                        repo.wheelhouseDir.absolutePath, repo.packageCacheDir.absolutePath
                    ).toString()
                    if (JSONObject(output).optBoolean("success")) {
                        python.getModule("runner").callAttr("refresh_package_imports", repo.packageDir.absolutePath)
                    }
                    output
                }
                val json = JSONObject(result)
                packageStatus.value = json.optString("message", "Package manager returned no details") +
                    if (json.optString("details").isNotBlank()) "\n" + json.optString("details") else ""
                pendingMessage.value = packageStatus.value.take(1800)
                refreshInstalledPackages()
            } catch (e: Exception) {
                packageStatus.value = "Install failed: ${e.message ?: "unknown package error"}"
            } finally {
                packageBusy.value = false
                PythonBridge.detach()
            }
        }
    }

    fun installWheel(tempWheel: File) {
        packageBusy.value = true
        packageStatus.value = "Checking wheel metadata and dependencies…"
        PythonBridge.reset()
        PythonBridge.attach(object : PythonBridge.Listener {
            override fun onOutput(text: String) { scope.launch(Dispatchers.Main.immediate) { packageStatus.value = text.takeLast(1200) } }
            override fun onInputRequested() { }
        })
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val python = Python.getInstance()
                    val output = python.getModule("pip_manager").callAttr(
                        "import_and_install_wheel", tempWheel.absolutePath,
                        repo.packageDir.absolutePath, repo.wheelhouseDir.absolutePath,
                        repo.packageCacheDir.absolutePath
                    ).toString()
                    if (JSONObject(output).optBoolean("success")) {
                        python.getModule("runner").callAttr("refresh_package_imports", repo.packageDir.absolutePath)
                    }
                    output
                }
                val json = JSONObject(result)
                packageStatus.value = json.optString("message", "Wheel installation finished") +
                    if (json.optString("details").isNotBlank()) "\n" + json.optString("details") else ""
                pendingMessage.value = packageStatus.value.take(1800)
                refreshInstalledPackages()
            } catch (e: Exception) {
                packageStatus.value = "Wheel installation failed: ${e.message ?: "unsupported wheel"}"
            } finally {
                packageBusy.value = false
                tempWheel.delete()
                PythonBridge.detach()
            }
        }
    }

    fun uninstallPackage(name: String) {
        packageBusy.value = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val python = Python.getInstance()
                    val output = python.getModule("pip_manager").callAttr("uninstall_package", name, repo.packageDir.absolutePath).toString()
                    if (JSONObject(output).optBoolean("success")) {
                        python.getModule("runner").callAttr("refresh_package_imports", repo.packageDir.absolutePath)
                    }
                    output
                }
                val json = JSONObject(result)
                packageStatus.value = json.optString("message", "Uninstall finished")
                pendingUninstallName.value = ""
                refreshInstalledPackages()
            } catch (e: Exception) {
                packageStatus.value = "Uninstall failed: ${e.message ?: "unknown error"}"
            } finally {
                packageBusy.value = false
            }
        }
    }

    fun setFontSize(value: Float) {
        fontSize.value = value.coerceIn(12f, 28f)
        repo.rememberFontSize(fontSize.value)
    }

    fun setDarkTheme(value: Boolean) {
        darkTheme.value = value
        repo.rememberDarkTheme(value)
    }

    fun setWordWrap(value: Boolean) {
        wordWrap.value = value
        repo.rememberWordWrap(value)
    }

    fun currentProjectName(): String = currentPath.value.substringBefore('/')
    fun currentFileName(): String = currentPath.value.substringAfterLast('/')

    fun clearTransientMessage() {
        pendingMessage.value = ""
    }

    fun dispose() {
        scope.cancel()
        PythonBridge.detach()
    }
}
