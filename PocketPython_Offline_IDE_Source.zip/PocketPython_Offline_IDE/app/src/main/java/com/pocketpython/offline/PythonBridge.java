package com.pocketpython.offline;

import androidx.annotation.Keep;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Java-static bridge intentionally kept by R8 because it is imported from embedded Python. */
@Keep
public final class PythonBridge {
    public interface Listener {
        void onOutput(String text);
        void onInputRequested();
    }

    private static volatile Listener listener;
    private static final LinkedBlockingQueue<String> INPUT = new LinkedBlockingQueue<>();
    private static volatile boolean cancelled = false;
    private static final String CANCEL_SENTINEL = "\u0000POCKETPYTHON_CANCEL";

    private PythonBridge() { }

    public static void attach(Listener newListener) {
        listener = newListener;
    }

    public static void detach() {
        listener = null;
    }

    public static void reset() {
        cancelled = false;
        INPUT.clear();
    }

    public static void write(String text) {
        Listener current = listener;
        if (current != null && text != null && !text.isEmpty()) current.onOutput(text);
    }

    public static String readLine() {
        Listener current = listener;
        if (current != null) current.onInputRequested();
        try {
            while (true) {
                String value = INPUT.poll(200, TimeUnit.MILLISECONDS);
                if (value != null) return value;
                if (cancelled || Thread.currentThread().isInterrupted()) return CANCEL_SENTINEL;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return CANCEL_SENTINEL;
        }
    }

    public static void submitInput(String value) {
        if (!cancelled) INPUT.offer(value == null ? "" : value);
    }

    public static void cancel() {
        cancelled = true;
        INPUT.offer(CANCEL_SENTINEL);
    }

    public static boolean isCancelled() {
        return cancelled;
    }
}
