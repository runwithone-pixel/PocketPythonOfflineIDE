#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python -m unittest discover -s tests -v
python -m py_compile app/src/main/python/runner.py app/src/main/python/pip_manager.py
python - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path('.')
for path in sorted(root.glob('app/src/main/**/*.xml')):
    ET.parse(path)
    print(f'XML OK: {path}')
PY
if command -v gradle >/dev/null 2>&1; then
  echo "Gradle detected; Android SDK availability will be checked by Gradle."
  gradle --no-daemon assembleDebug
else
  echo "Gradle not found. Host tests passed, but Android build was skipped." >&2
fi
